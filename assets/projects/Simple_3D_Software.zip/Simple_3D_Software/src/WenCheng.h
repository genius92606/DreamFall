#ifndef _WEN_CHENG_H_
#define _WEN_CHENG_H_

#include "Texture.h"
#include "StaticMesh.h"
#include "ShaderProgram.h"
#include "ScopeResource.h"

#endif